from myIO import getPhotoList, printOutput

def onlyVertical(inList, bool):
    return list(filter(lambda a : a.isVertical() == bool, inList))

def photoListToTags(photoList):
    return [x.getTags() for x in photoList]

def photoListToIndex(photoList):
    return [x.getIndex() for x in photoList]

def addListLayer(inList):
    return [[x] for x in inList]


def pairVerticals(vertPhotos):
    if len(vertPhotos) % 2 == 1:
        vertPhotos.pop()
    usedPhotos=[]
    noUsePhotos=[]
    for photo in vertPhotos:
        if photo in noUsePhotos:
            continue
        maxTags=0
        secondPhoto=photo

        for photo2 in vertPhotos:
            if photo2 in noUsePhotos:
                continue
            score= len(set(photo.getTags()+photo2.getTags()))
            if(score>maxTags):
                secondPhoto=photo2
                maxTags=score
        usedPhotos.append([photo,secondPhoto])
        noUsePhotos.append(photo)
        noUsePhotos.append(secondPhoto)




    return usedPhotos

def dumbSolution(num):
    allPics = getPhotoList(num)
    ho = addListLayer(onlyVertical(allPics, False))
    ve = onlyVertical(allPics, True)
    printOutput(num, ho + pairVerticals(ve))

for x in range(5):
    dumbSolution(x)
